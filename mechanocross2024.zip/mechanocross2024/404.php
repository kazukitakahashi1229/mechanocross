<?php get_header(); ?>

<!-- <div class="page__header">
    <div class="container md">
        <div class="page__header__cont">
            <h1 class="t-white">ページが見つかりませんでした</h1>
            <p class="font-en t-white">404</p>
        </div>
    </div>
</div>

<main id="main" class="js-anime anime-fadeInUp">
    <div class="container md">
        <p class="">誠に申し訳ございません。<br class="show_sp">お探しのページは見つかりませんでした。</p>
        <p class="">お探しのページは一時的にアクセスができない状況にあるか、移動もしくは削除された可能性があります。</p>
        <a class="button outline-black" href="<?php echo esc_url( home_url('/') ); ?>">back to top</a>
    </div>
</main> -->

<!-- <?php get_template_part('template-parts/cta'); ?> -->

<?php get_footer(); ?>